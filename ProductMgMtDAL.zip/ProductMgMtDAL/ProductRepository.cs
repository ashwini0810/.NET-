﻿using Microsoft.EntityFrameworkCore;
using ProductMgMtDAL.Entites;

namespace ProductMgMtDAL;

public class ProductRepository : IRepository<Product>
{
    ShoppingContext context;

    public ProductRepository(ShoppingContext context)
    {
        this.context = context;
    }

    public List<Product> GetAllProducts()
    {
        return context.Products.ToList();
    }

    public Product GetProductById(int id)
    {
        return context.Products.Find(id);
    }

    public void AddProduct(Product product)
    {
        context.Products.Add(product);
        context.SaveChanges();
    }

    public void UpdateProduct(Product product)
    {
        context.Entry(product).State = EntityState.Modified;
        context.SaveChanges();
    }


    public IEnumerable<Product> GetAll()
    {
        throw new NotImplementedException();
    }

    public IEnumerable<Product> SearchByName(string name)
    {
        throw new NotImplementedException();
    }

    public Product GetById(int id)
    {
        throw new NotImplementedException();
    }

    public Product Add(Product item)
    {
        throw new NotImplementedException();
    }

    public Product Update(Product item)
    {
        throw new NotImplementedException();
    }

    public void Delete(int id)
    {
        throw new NotImplementedException();
    }

    IEnumerable<Product> IRepository<Product>.GetAll()
    {
        throw new NotImplementedException();
    }

    IEnumerable<Product> IRepository<Product>.SearchByName(string name)
    {
        throw new NotImplementedException();
    }

    Product IRepository<Product>.GetById(int id)
    {
        throw new NotImplementedException();
    }

    Product IRepository<Product>.Add(Product item)
    {
        throw new NotImplementedException();
    }

    Product IRepository<Product>.Update(Product item)
    {
        throw new NotImplementedException();
    }
}


