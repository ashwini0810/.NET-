﻿using ProductMgMtDAL.Entites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductMgMtDAL;
public interface IRepository<T>
{
    IEnumerable<T> GetAll();

    IEnumerable<T> SearchByName(string name);

    T GetById(int id);

    T Add(T item);
    T Update(T item);
    
}