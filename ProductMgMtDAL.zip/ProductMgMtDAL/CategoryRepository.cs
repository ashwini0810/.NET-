﻿using ProductMgMtDAL.Entites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductMgMtDAL
{
    public class CategoryRepository: IRepository<Category>
    {

        ShoppingContext context;


    public CategoryRepository(ShoppingContext context)
    {
        this.context = context;
    }
    public Category Add(Category item)
    {
        throw new NotImplementedException();
    }

    public Category Delete(Category item)
    {
        throw new NotImplementedException();
    }

    public IEnumerable<Category> GetAll()
    {
        var query = from Categories in context.Categories
                    where Categories.CategoryId == 1
                    orderby Categories.Name ascending
                    select Categories;
        return query;
    }

    public Category GetById(int id)
    {
        throw new NotImplementedException();
    }

    public IEnumerable<Category> SearchByName(string name)
    {
        throw new NotImplementedException();
    }

    public Category Update(Category item)
    {
        throw new NotImplementedException();
    }
}
}

   