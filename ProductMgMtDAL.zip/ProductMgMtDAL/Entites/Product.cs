﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ProductMgMtDAL.Entites;
[Table("Products")]
public class Product
    {
    

    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int ProductId { get; set; }

    [Required]
        public string Name { get; set; }

    [Required]
    [Column(TypeName = "date")]
    public DateTime MfgDate { get; set; }
    [Required]
    public double Price { get; set; }

        public int Stock {  get; set; }
    [Required]
    public double GST { get; set; }
    [Required]
    public double Discount { get; set; }
         
    public int Quantity {  get; set; }
        public Byte Status { get; set; }
    [Required]
    public int CategoryId {  get; set; }

}

