﻿using System;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



    namespace ProductMgMtDAL.Entites;
    public class ShoppingContext : DbContext
    {
        public ShoppingContext(DbContextOptions<ShoppingContext>
                options) : base(options)
        {

        }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .Entity<Product>().HasData(
            new Product { ProductId = 1, Name = "Product1" },
            new Product { ProductId = 2, Name = "Product2" },
            new Product { ProductId = 3, Name = "Product3" });

        modelBuilder.Entity<Category>()
            .HasData(
             new Category
             {
                 CategoryId = 1,
                 Name = "A",

                 //ID = 1
             },
             new Category
             {
                 CategoryId = 2,
                 Name = "B",

                 // ID = 2
             },
             new Category
             {
                 CategoryId = 3,
                 Name = "C",
                 // ID = 3
             }
        );
    }



    public DbSet<Product> Products { get; set; }
    public DbSet<Category> Categories { get; set; }
    }

