﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccountUnitTest;

    public class UnitTestMathController
    {
    public  UnitTestMathController()
    {

    }
    }

