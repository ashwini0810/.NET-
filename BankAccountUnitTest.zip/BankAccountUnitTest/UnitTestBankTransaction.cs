using BankApp;

namespace BankAccountUnitTest
{
    public class UnitTestBankTransaction : IDisposable
    {
        BankTransaction bankTransaction;
        public UnitTestBankTransaction()
        {
            bankTransaction = new BankTransaction();
        }
        //cleanup
        public void Dispose()
        {
        }
        [Fact]
        public void BankTran_Deposit_Amount_Account_Valid_Balance_Increases()
        {
            //Arrange
            Account account = new Account
            {
                AccountId = 10,
                Balance = 10000,
                Name = "Customer1"
            };
            double depositamt = 1000;

            //Act
            bankTransaction.Deposit(account, depositamt);

            //Assert
            Assert.NotNull(bankTransaction);
            Assert.IsType<BankTransaction>(bankTransaction);

            double expectedbalance = 11000;
            double actualbalance = account.Balance;
            Assert.Equal<double>(expectedbalance, actualbalance);


        }
        [Fact]
        public void BankTran_Deposit_Amount_zero_Throws_ArgumentException()
        {
            Account account = new Account
            {
                AccountId = 20,
                Balance = 20000,
                Name = "Customer1"
            };
            double depositamt = 0;

            //Act
            //bankTransaction.Deposit(account, depositamt);

            //assert
            Action action = () => bankTransaction.Deposit(account, depositamt);
            Assert.Throws<ArgumentException>(action);
        }

        public void BankTran_Deposit_Amount_Act_Valid_balance_decreases()
        {
            Account account = new Account
            {
                AccountId = 10,
                Balance = 10000,
                Name = "Customer1"
            };
            double withdrwamt = 2000;

            //Act
            bankTransaction.Withdraw(account, withdrwamt);

            //Assert
            Assert.NotNull(bankTransaction);
            Assert.IsType<BankTransaction>(bankTransaction);

            double expectedbalance = 8000;
            double actualbalance = account.Balance;
            Assert.Equal<double>(expectedbalance, actualbalance);


        }
        public void BankTran_Withdraw_Amount_zero_Throws_ArgumentException()
        {
            Account account = new Account
            {
                AccountId = 20,
                Balance = 10000,
                Name = "Customer1"
            };
            double withdrawamt = 0;

            //Act
            bankTransaction.Withdraw(account, withdrawamt);

            //Assert
            
            Action action = () => bankTransaction.Withdraw(account, withdrawamt);
            Assert.Throws<ArgumentException>(action);


        }
        public void BankTran_Withdraw_balance_gt_amt_Throws_InvalidOperationException()
        {
            Account account = new Account
            {
                AccountId = 10,
                Balance = 10000,
                Name = "Customer1"
            };
            double withdrawamt = 1000;

            //Act
            bankTransaction.Withdraw(account, withdrawamt);

            //assert
            Action action = () => bankTransaction.Withdraw(account, withdrawamt);
            Assert.Throws<InvalidOperationException>(action);



        }
    }

}