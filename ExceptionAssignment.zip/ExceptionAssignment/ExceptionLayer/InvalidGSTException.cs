﻿using System;
using System.Runtime.Serialization;

namespace ExceptionAssignment
{
    [Serializable]
    internal class InvalidGSTException : Exception
    {
        public InvalidGSTException()
        {
        }

        public InvalidGSTException(string message) : base(message)
        {
        }

        public InvalidGSTException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected InvalidGSTException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}