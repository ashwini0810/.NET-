﻿using System;
using System.Runtime.Serialization;

namespace ExceptionAssignment
{
    [Serializable]
    internal class InvalidPurchaseDateException : Exception
    {
        public InvalidPurchaseDateException()
        {
        }

        public InvalidPurchaseDateException(string message) : base(message)
        {
        }

        public InvalidPurchaseDateException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected InvalidPurchaseDateException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}