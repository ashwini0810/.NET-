﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionAssignment
{
     class Program
    {
        static void Main(string[] args)
        {

            List<Product> prods = null;
            int choice;

            do
            {
                Console.WriteLine("Menu:");
                Console.WriteLine("1. Add");
                Console.WriteLine("2. Display all");
                Console.WriteLine("3. Find");
                Console.WriteLine("4. Remove");
                Console.WriteLine("5. Exit");
                Console.Write("Enter your choice: ");

                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:

                        prods = new List<Product>();
                        ; string ans = "y";

                        do
                        {
                            Console.WriteLine("a. Mobile");
                            Console.WriteLine("b. TV");
                            Console.Write("Enter your choice (a/b): ");
                            char productType = Console.ReadLine().ToLower()[0];

                            switch (productType)
                            {
                                case 'a':
                                    Mobile mobile = new Mobile();


                                Try_Name:
                                    try
                                    {
                                        Console.Write("Enter Name: ");
                                        mobile.Name = Console.ReadLine();
                                    }
                                    catch (InvalidNameException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Try_Name;
                                    }
                                    catch (FormatException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                    }


                                Try_PurchaseDate:
                                    try
                                    {
                                        Console.Write("Enter Purchase Date (yyyy-MM-dd): ");
                                        mobile.PurchaseDate = Convert.ToDateTime(Console.ReadLine());
                                    }
                                    catch (InvalidPurchaseDateException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Try_PurchaseDate;
                                    }
                                    catch (FormatException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Try_PurchaseDate;
                                    }


                                Try_Price:
                                    try
                                    {
                                        Console.Write("Enter Price: ");
                                        mobile.Price = Convert.ToDecimal(Console.ReadLine());
                                    }
                                    catch (InvalidPriceException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Try_Price;
                                    }
                                    catch (FormatException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Try_PurchaseDate;
                                    }


                                Try_GST:
                                    try
                                    {
                                        Console.Write("Enter GST (5, 12, 18, 28): ");
                                        mobile.GST = Convert.ToInt32(Console.ReadLine());
                                    }
                                    catch (InvalidGSTException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Try_GST;
                                    }


                                Try_Discount:
                                    try
                                    {
                                        Console.Write("Enter Discount (0-25%): ");
                                        mobile.Discount = Convert.ToDecimal(Console.ReadLine());
                                    }
                                    catch (InvalidDiscountException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Try_Discount;
                                    }


                                Try_Quantity:
                                    try
                                    {
                                        Console.Write("Enter Quantity: ");
                                        mobile.Quantity = Convert.ToInt32(Console.ReadLine());
                                    }
                                    catch (InvalidQuantityException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Try_Quantity;
                                    }


                                    Console.Write("Is it a 5G phone? (true/false): ");
                                    mobile.Is5G = Convert.ToBoolean(Console.ReadLine());


                                    Console.Write("Enter OS: ");
                                    mobile.OS = Console.ReadLine();



                                    mobile.ProductId = mobile.GenerateProductId(mobile.Name, mobile.PurchaseDate);

                                    prods.Add(mobile);
                                    break;

                                case 'b':
                                    TV tv = new TV();
                                //Console.Write("Enter Product ID: ");
                                //tv.ProductId = Convert.ToInt32(Console.ReadLine());


                                Tryt_Name:
                                    try
                                    {
                                        Console.Write("Enter Name: ");
                                        tv.Name = Console.ReadLine();
                                    }
                                    catch (InvalidNameException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Tryt_Name;
                                    }


                                Tryt_PurchaseDate:
                                    try
                                    {
                                        Console.Write("Enter Purchase Date (yyyy-MM-dd): ");
                                        tv.PurchaseDate = DateTime.Parse(Console.ReadLine());
                                    }
                                    catch (InvalidPurchaseDateException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Tryt_PurchaseDate;
                                    }


                                Tryt_Price:
                                    try
                                    {
                                        Console.Write("Enter Price: ");
                                        tv.Price = Convert.ToDecimal(Console.ReadLine());
                                    }
                                    catch (InvalidPriceException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Tryt_Price;
                                    }


                                Tryt_GST:
                                    try
                                    {
                                        Console.Write("Enter GST (5, 12, 18, 28): ");
                                        tv.GST = Convert.ToInt32(Console.ReadLine());
                                    }
                                    catch (InvalidGSTException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Tryt_GST;
                                    }


                                Tryt_Discount:
                                    try
                                    {
                                        Console.Write("Enter Discount (0-25%): ");
                                        tv.Discount = Convert.ToDecimal(Console.ReadLine());
                                    }
                                    catch (InvalidDiscountException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Tryt_Discount;
                                    }


                                Tryt_Quantity:
                                    try
                                    {
                                        Console.Write("Enter Quantity: ");
                                        tv.Quantity = Convert.ToInt32(Console.ReadLine());
                                    }
                                    catch (InvalidQuantityException ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                        goto Tryt_Quantity;
                                    }

                                    Console.Write("Is it a Smart TV? (true/false): ");
                                    tv.IsSmart = Convert.ToBoolean(Console.ReadLine());

                                    Console.Write("Enter Number of HDMI Ports: ");
                                    tv.NoHDMI = Convert.ToInt32(Console.ReadLine());

                                    tv.ProductId = tv.GenerateProductId(tv.Name, tv.PurchaseDate);

                                    prods.Add(tv);


                                    break;

                                default:
                                    Console.WriteLine("Invalid choice. Please try again.");
                                    break;
                            }

                            Console.WriteLine("Do you want to continue(y/n): ");
                            string ans1 = Console.ReadLine().ToLower();
                            ans = ans1;

                        } while (ans == "y");



                        break;




                    case 2:

                        if (prods != null)
                        {
                            foreach (Product item in prods)
                            {
                                Console.WriteLine(item.Display());
                            }
                        }
                        else
                            Console.WriteLine("No product added yet.");
                        break;

                    case 3:

                        if (prods == null)
                        {
                            Console.WriteLine("No product added to find. ");
                        }
                        else
                        {
                            Console.WriteLine("Product ids\n");
                            foreach (Product item in prods)
                            {
                                Console.WriteLine(item.ProductId);
                            }

                            Console.WriteLine("Enter the ProductId to find :");
                            string findId = Console.ReadLine();
                            foreach (Product item in prods)
                            {
                                if (item != null && item.ProductId == findId)
                                {
                                    Console.WriteLine(item.Display());
                                }
                                else
                                {
                                    Console.WriteLine("Product not found");
                                }
                            }
                        }

                        break;

                    case 4:

                        if (prods == null)
                        {
                            Console.WriteLine("No product added to Remove. ");
                        }
                        else
                        {
                            Console.WriteLine("Product ids:");
                            foreach (Product item in prods)
                            {
                                Console.WriteLine(item.ProductId);
                            }

                            Console.WriteLine("\nEnter the ProductId to be removed :");
                            string removeId = Console.ReadLine();
                            foreach (Product item in prods)
                            {
                                if (item.ProductId == removeId)
                                {
                                    Console.WriteLine(item.Display());
                                    prods.Remove(item);
                                    Console.WriteLine("The above Product has been removed");
                                    break;
                                }
                                else
                                {
                                    Console.WriteLine("Enter valid ProductId");
                                }
                            }
                        }

                        break;


                    case 5:
                        Console.WriteLine("Exiting program.");
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }

            } while (choice != 5);
        }
    }


}
       
