﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionAssignment
{
    class Product
    {
        public string ProductId;
        private string name;
        private DateTime purchaseDate;
        private DateTime warranty;
        private decimal price;
        private int gst;
        private decimal discount;
        private int quantity;
        private int productCounter;

        public Product()
        {
            productCounter++;
        }






        //public string ProductId
        //{
        //    get,
        //    private set { }
        //}



        public string Name
        {
            get { return name; }
            set
            {
                if (value.Length > 3)
                    name = value;
                else
                    throw new InvalidNameException("Name must contain more then 4 chars. ");
            }
        }

        public DateTime PurchaseDate
        {
            get { return purchaseDate; }
            set
            {
                if (value.CompareTo(DateTime.Now) < 0)
                {
                    purchaseDate = value;
                    warranty = PurchaseDate.AddYears(1);
                }
                else
                {
                    throw new InvalidPurchaseDateException("Date must be less then todays date");
                }
            }
        }

        public DateTime Warranty
        {
            get { return warranty; }
        }

        public decimal Price
        {
            get { return price; }
            set
            {
                if (value > 0)
                    price = value;
                else
                    throw new InvalidPriceException("Price must be greater than 0.");
            }
        }

        public int GST
        {
            get { return gst; }
            set
            {
                if (value == 5 || value == 12 || value == 18 || value == 28)
                    gst = value;
                else
                    throw new InvalidGSTException("Invalid GST rate.");
            }
        }

        public decimal Discount
        {
            get { return discount; }
            set
            {
                if (value > 0 && value < 25)
                    discount = value;
                else
                    throw new InvalidDiscountException("Discount must be between 0 and 25.");
            }
        }

        public int Quantity
        {
            get { return quantity; }
            set
            {
                if (value > 0)
                    quantity = value;
                else
                    throw new InvalidQuantityException("Quantity must be greater than 0.");
            }
        }

        public string GenerateProductId(string Name, DateTime purchaseDate)
        {
            string n = Name;
            string d = purchaseDate.ToString();
            string namePart = Name.Substring(Name.Length - 3);
            string monthPart = purchaseDate.Month.ToString("D2");
            string yearPart = purchaseDate.Year.ToString();
            string counterPart = productCounter.ToString("D2");

            return $"{namePart}{monthPart}{yearPart}00{counterPart}";
        }

        public virtual string Display()
        {
            return $"Product ID: {ProductId}\nName: {Name}\n" +
                $"Purchase Date: {PurchaseDate.ToShortDateString()}\n" +
                $"Warranty: {warranty}\nPrice: {Price}\nGST: {GST}%\n" +
                $"Discount: {Discount}%\nQuantity: {Quantity}\n" +
                $"Tax Price: {CalculateTaxPrice()}\n" +
                $"Discount Price: {CalculateDiscountPrice()}\n" +
                $"Total Cost: {CalculateTotalCost()}\n";
        }

        private decimal CalculateTaxPrice()
        {
            return (Price + Price * (GST) / 100);
        }

        private decimal CalculateDiscountPrice()
        {
            return (CalculateTaxPrice() - (CalculateTaxPrice() * Discount / 100));
        }

        private decimal CalculateTotalCost()
        {
            return CalculateDiscountPrice() * Quantity;
        }
    }

    internal class Mobile : Product
    {
        private bool is5G;

        public bool Is5G
        {
            get
            {
                return is5G;
            }
            set { is5G = value; }
        }

        private string os;

        public string OS
        {
            get { return os; }
            set { os = value; }
        }

        public override string Display()
        {
            string msg = base.Display();
            StringBuilder sb = new StringBuilder();
            sb.Append(msg);
            if (is5G)
            {
                sb.Append("This is an 5g phone\n");
            }
            else
            {
                sb.Append("This is not an 5g phone\n");
            }
            sb.Append(os);
            return sb.ToString();

        }


    }

    class TV : Product
    {
        public bool IsSmart { get; set; }
        public int NoHDMI { get; set; }

        public override string Display()
        {
            string msg = base.Display();
            StringBuilder sb = new StringBuilder(msg);

            sb.AppendLine($"Smart TV: {IsSmart}");
            sb.AppendLine($"Number of HDMI Ports: {NoHDMI}");

            return sb.ToString();
        }
    }


}
