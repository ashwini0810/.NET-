﻿namespace ProductCatalogSvc.Data
{
    public interface IRepository
    {
    }
}
