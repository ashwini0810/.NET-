﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp;

    public  class BankTransaction
    {
    public void Deposit (Account account, double amt) {
        if (amt == 0)
            throw new ArgumentException("Amount is zero to deposit ");
        if (account == null)
            throw new ArgumentNullException("Account for deposit is null");
        account.Balance += amt;
    }

    public void Withdraw(Account account, double amt) 
    {
        if (amt == 0)
            throw new ArgumentException("Amount is zero to withdraw");
        if (account == null)
            throw new ArgumentNullException("Account for deposit is null");

        if (account.Balance < amt)
            throw new InvalidOperationException("Insufficient fund");
        account.Balance -= amt;
    }

    public void Transfer(Account account, Account account1,double amt) {
        if (amt == 0)
            throw new ArgumentException("Amount is zero so cannot transfer ");
        if (account == null || account1 == null)
            throw new ArgumentNullException("One of account is invalid cannot transfer");
        account.Balance -= amt;
        account.Balance += amt;
    }
}
    }

