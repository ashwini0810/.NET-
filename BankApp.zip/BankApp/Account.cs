﻿namespace BankApp
{
    public class Account
    {
        public int AccountId { get; set; }

        public string Name { get; set; }

        public double Balance { get; set; }
    }
}