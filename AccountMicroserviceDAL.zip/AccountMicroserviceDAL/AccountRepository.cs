﻿namespace AccountMicroserviceDAL
{
    public class Class1
    {

    }
}