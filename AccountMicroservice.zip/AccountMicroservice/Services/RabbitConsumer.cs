﻿
using AccountMicroservice.Data;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;
using System.Text.Json;

namespace AccountMicroservice.Services;

public class RabbitConsumer
    {
        private readonly IRepository repository;

        public RabbitConsumer(IRepository repository)
        {
            this.repository = repository;
        }
        public void Consume()
        {
            var factory = new ConnectionFactory
            {
                HostName = "localhost"
            };

            var connection = factory.CreateConnection();

            var channel = connection.CreateModel();

            channel.ExchangeDeclare("ordering", "direct",
                true, false, null);
            channel.QueueDeclare("accountidsQ", true, false, false, null);
            channel.QueueBind("accountidsQ", "ordering", "rkord", null);

            var eventconsumer = new EventingBasicConsumer(channel);

            eventconsumer.Received += (sender, eventArgs) =>
            {
                var body = eventArgs.Body.ToArray();
                var jsonstring = Encoding.UTF8.GetString(body);
                var mydict = JsonSerializer
                        .Deserialize<Dictionary<int, int>>(jsonstring);

                foreach (var item in mydict.Keys)
                {
                    repository.UpdateStockForAccount(item, mydict[item]);
                }
            };

            channel.BasicConsume("accountidsQ", true, eventconsumer);
        }
    }
}
