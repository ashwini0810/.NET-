﻿namespace AccountMicroservice.Data
{
    
        public class AccountInMemoryRepo : IRepository
        {
            List<Account> accounts;

            public AccountInMemoryRepo()
            {
                accounts = new List<Account>
        {
            new Account { Id = 1, Name = "John Doe", Mobile = "1234567890", Email = "john@example.com", Balance = 1000, AccountType = "Savings" },
            new Account { Id = 2, Name = "Jane Smith", Mobile = "9876543210", Email = "jane@example.com", Balance = 500, AccountType = "Checking" }
            // Add more initial accounts as needed
        };
            }

            public void Add(Account account)
            {
                if (accounts.Any(a => a.Id == account.Id))
                {
                    throw new Exception("Account already exists");
                }
                else
                {
                    accounts.Add(account);
                }
            }

            public IEnumerable<Account> GetAll()
            {
                return accounts.OrderBy(a => a.Name);
            }

            public Account GetById(int id)
            {
                return accounts.SingleOrDefault(a => a.Id == id) ?? throw new Exception("Account not found");
            }

            public void UpdateBalanceForAccount(int accountId, decimal amount)
            {
                var account = GetById(accountId);
                account.Balance += amount;
            }

        public void UpdateStockForAccount(int item, int v)
        {
            throw new NotImplementedException();
        }

        // Additional methods for update, delete, or specific account operations can be added as required
    }

    }
}
