﻿namespace AccountMicroservice.Data
{
    

    public interface IRepository
    {
        IEnumerable<Account> GetAll();
        Account GetById(int id);
        void Add(Account account);
        void UpdateStockForAccount(int item, int v);

        // void UpdateStockForAccount(int pid, int qty);
    }
}
