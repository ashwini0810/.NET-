using AccountMicroservice.Data;

using AccountMicroservice.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
//builder.Services.AddSingleton<IRepository, AccountInMemoryRepo>();

builder.Services.AddSingleton<RabbitConsumer>();


var app = builder.Build();

var rabcosumer = app.Services
    .GetRequiredService<RabbitConsumer>();

rabcosumer.Consume();

app.MapControllers();

app.Run();
