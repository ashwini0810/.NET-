﻿
using AccountMicroservice.Data;
using Microsoft.AspNetCore.Mvc;
using NuGet.Protocol.Core.Types;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AccountMicroservice.Controllers;
[Route("api/[controller]")]
[ApiController]
public AccountController : ControllerBase

    public readonly IRepository repository;

    public AccountController(IRepository repository)
    {
        this.repository = repository;
    }

    [HttpGet]
    public IActionResult Get()
    {
        return Ok(Repository.GetAll());
    }

    // GET api/<ProductController>/5
    [HttpGet("{id}")]
    public IActionResult Get(int id)
    {
        return Ok(repository.GetById(id));
    }

    // POST api/<ProductController>
    [HttpPost]
    public IActionResult Post([FromBody] Account value)
    {
        try
        {
            repository.Add(value);
            return Ok("Account added successfully");
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = ex.Message });
        }
    }

    // PUT api/<ProductController>/5
    [HttpPut("{id}")]
    public void Put(int id, [FromBody] string value)
    {
    }

    // DELETE api/<ProductController>/5
    [HttpDelete("{id}")]
    public void Delete(int id)
    {
    }
